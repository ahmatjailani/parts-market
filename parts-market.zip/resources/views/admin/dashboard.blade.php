@extends('admin.layout.app')
@section('title', 'Dashboard')
@section('content-admin')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h3>Dashboard</h3>
            </div>
        </div>
    </div>
@endsection
