
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content-admin'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h3>Dashboard</h3>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dataagung\fastwork\parts-market\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>