
<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('content-admin'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(isset($product) ? 'Edit Product' : 'Create Product'); ?>

                    </div>
                    <div class="card-body card-block">
                        <form
                            action="<?php echo e(isset($product) ? route('products.update', $product->id) : route('products.store')); ?>"
                            method="post" enctype="multipart/form-data" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($product)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="product_name" class="form-control-label">Nama Produk</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <input type="text" id="product_name" name="product_name"
                                        value="<?php echo e(isset($product) ? $product->name : ''); ?>"
                                        placeholder="Masukkan Nama Produk" class="form-control">
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="category" class="form-control-label">Pilih Kategori</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <select name="category" id="category" class="form-control">
                                        <option value="">Silahkan Pilih</option>
                                        <?php $__currentLoopData = $categoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e(Crypt::encrypt($item->id)); ?>"
                                                <?php echo e(isset($product) && $product->category_id == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="status" class="form-control-label">Pilih Status</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <select name="status" id="status" class="form-control">
                                        <option value="">Silahkan Pilih</option>
                                        <option value="ready"
                                            <?php echo e(isset($product) && $product->status == 'ready' ? 'selected' : ''); ?>>Tersedia
                                        </option>
                                        <option value="soon"
                                            <?php echo e(isset($product) && $product->status == 'soon' ? 'selected' : ''); ?>>Segera
                                            Hadir</option>
                                        <option value="not_ready"
                                            <?php echo e(isset($product) && $product->status == 'not_ready' ? 'selected' : ''); ?>>Tidak
                                            Tersedia</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="price" class="form-control-label">Harga Produk</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <input type="text" id="price" name="price"
                                        value="<?php echo e(isset($product) ? $product->price : ''); ?>"
                                        placeholder="Masukkan Harga Produk" class="form-control">
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="specification" class="form-control-label">Spesifikasi</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <textarea name="specification" id="specification" rows="9" placeholder="Masukkan Spesifikasi"
                                        class="form-control"><?php echo e(isset($product) ? $product->specification : ''); ?></textarea>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="product_images" class="form-control-label">Foto Produk</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <input type="file" id="product_images" name="product_images[]" multiple
                                        class="form-control-file">
                                </div>
                            </div>

                            <!-- Menampilkan gambar yang sudah ada -->
                            <?php if(isset($product) && $product->images->count() > 0): ?>
                                <div class="row form-group">
                                    <div class="col col-md-3">
                                        <label for="existing_images" class="form-control-label">Gambar Saat Ini</label>
                                    </div>
                                    <div class="col-12 col-md-9">
                                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-3">
                                                <img src="<?php echo e(asset($image->image_path)); ?>" alt="Product Image"
                                                    width="100">
                                                <a href="<?php echo e(route('products.removeImage', $image->id)); ?>"
                                                    class="btn btn-danger btn-sm">Hapus</a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <i class="fa fa-dot-circle-o"></i> <?php echo e(isset($product) ? 'Update' : 'Submit'); ?>

                                </button>
                                <a type="button" class="btn btn-success btn-sm" href="<?php echo e(route('products.index')); ?>">
                                    <i class="fa fa-step-backward"></i> Back
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dataagung\fastwork\parts-market\resources\views/admin/product/form.blade.php ENDPATH**/ ?>