
<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('content-admin'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(isset($services) ? 'Edit Services' : 'Create Services'); ?>

                    </div>
                    <div class="card-body card-block">
                        <form
                            action="<?php echo e(isset($services) ? route('services.update', $services->id) : route('services.store')); ?>"
                            method="post" enctype="multipart/form-data" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($services)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>

                            <!-- For name field -->
                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="service_name" class="form-control-label">Nama Service</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <input type="text" id="service_name" name="name"
                                        value="<?php echo e(old('name', isset($services) ? $services->name : '')); ?>"
                                        placeholder="Masukkan Nama Service" class="form-control">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- For category field -->
                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="category" class="form-control-label">Pilih Kategori</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <select name="category" id="category" class="form-control">
                                        <option value="">Silahkan Pilih</option>
                                        <?php $__currentLoopData = $categoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e(Crypt::encrypt($item->id)); ?>"
                                                <?php echo e(old('category', isset($services) ? $services->category_services_id : '') == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- For car field -->
                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="car" class="form-control-label">Pilih Mobil</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <select name="car_id" id="car" class="form-control">
                                        <option value="">Silahkan Pilih</option>
                                        <?php $__currentLoopData = $carData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e(Crypt::encrypt($item->id)); ?>"
                                                <?php echo e(old('car_id', isset($services) ? $services->car_id : '') == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['car_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="price" class="form-control-label">Harga Service</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <input type="text" id="price" name="price"
                                        value="<?php echo e(isset($services) ? $services->price : ''); ?>"
                                        placeholder="Masukkan Harga Service" class="form-control">
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col col-md-3">
                                    <label for="specification" class="form-control-label">Spesifikasi</label>
                                </div>
                                <div class="col-12 col-md-9">
                                    <textarea name="specification" id="specification" rows="9" placeholder="Masukkan Spesifikasi"
                                        class="form-control"><?php echo e(isset($services) ? $services->specification : ''); ?></textarea>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <i class="fa fa-dot-circle-o"></i> <?php echo e(isset($services) ? 'Update' : 'Submit'); ?>

                                </button>
                                <a type="button" class="btn btn-success btn-sm" href="<?php echo e(route('services.index')); ?>">
                                    <i class="fa fa-step-backward"></i> Back
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            // Check if the category is Konversi
            $('#category').on('change', function() {
                var category = $(this).find('option:selected')
                    .text().trim(); // Get the text of the selected option
                console.log(category); // Log the selected category for debugging

                // If "Konversi" is selected, enable the car selection
                if (category == 'Konversi') {
                    $('#car').prop('disabled', false); // Enable the car dropdown
                } else {
                    $('#car').prop('disabled', true); // Disable the car dropdown
                }
            }).trigger('change'); // Trigger change event on page load to set the initial state
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dataagung\fastwork\parts-market\resources\views/admin/services/form.blade.php ENDPATH**/ ?>